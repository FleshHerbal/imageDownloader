﻿using System;
using System.Net;
using System.Runtime.Serialization;

namespace ConsoleApp1
{
    class ImDown
    {

        static void Main(string[] args)
        {
            WebClient client = new WebClient();
            Random rnd = new Random();
            string url;
            string filescape;
            int x;
            int y;
            int str;

            Console.WriteLine("Ширина");
            x = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Длина");
            y = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Кол-во загружаемых файлов");
            str = Convert.ToInt32(Console.ReadLine());

            filescape = $@"C:\\ImageImDown\\Image{x}-{y}\\";
            System.IO.Directory.CreateDirectory(filescape);




            for (int i = 0; i < str; i++)
            {
                 
                string namefile = $"image{i.ToString()}.png";
                Console.WriteLine($"Загрузка файла:_{namefile}");

                url = "https://picsum.photos/" + x + "/" + y;

                {
                    client.DownloadFile(url, filescape + namefile);
                }

            }

            Console.WriteLine("DONE");
            Console.WriteLine($"Файлы загруженны в папку:{filescape}");
            Console.ReadLine();


        }
    }
}
